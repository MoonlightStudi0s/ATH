import os
import re
import json
import sqlite3
import random
import urllib.request
import urllib.parse
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from openai import OpenAI

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'roadhelper_pro_secure_key_991828')

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'roadhelper.db')

GROQ_API_KEY = "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"
client = OpenAI(
    api_key=GROQ_API_KEY,
    base_url="https://api.groq.com/openai/v1",
)

CITY_REGISTRY = {
    "москва": [37.6173, 55.7558],
    "владимир": [40.4066, 56.1290],
    "суздаль": [40.4489, 56.4193],
    "нижний новгород": [44.0065, 56.3269],
    "чебоксары": [47.2515, 56.1439],
    "казань": [49.1210, 55.7903],
    "санкт-петербург": [30.3141, 59.9386]
}

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password_hash TEXT,
            coins INTEGER DEFAULT 500,
            avatar_url TEXT DEFAULT 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            item_id TEXT,
            item_name TEXT,
            bought_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_checkpoints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            checkpoint_id TEXT,
            status TEXT DEFAULT 'available',
            progress TEXT DEFAULT '0/1',
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_routes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            start_point TEXT,
            end_point TEXT,
            days INTEGER,
            distance INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def clean_json_string(s):
    s = s.replace('\n', ' ').replace('\r', ' ')
    cleaned = re.sub(r'(?<=:\s")(.+?)(?="\s*[,}])', lambda m: m.group(1).replace('"', '«'), s)
    return cleaned

def get_city_coordinates(city_name, fallback_coords):
    city_cleaned = city_name.strip().lower()
    if not city_cleaned:
        return fallback_coords
    if city_cleaned in CITY_REGISTRY:
        return CITY_REGISTRY[city_cleaned]
    try:
        url_city = urllib.parse.quote(f"{city_name}, Россия")
        url = f"https://nominatim.openstreetmap.org/search?q={url_city}&format=json&limit=1"
        req = urllib.request.Request(url, headers={'User-Agent': 'RoadHelper_Bot_v6'})
        with urllib.request.urlopen(req, timeout=4) as response:
            data = json.loads(response.read().decode())
            if data:
                coords = [float(data[0]['lon']), float(data[0]['lat'])]
                CITY_REGISTRY[city_cleaned] = coords
                return coords
    except Exception:
        pass
    return fallback_coords

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    
    if not username or not password:
        return jsonify({"success": False, "error": "Имя пользователя и пароль обязательны для заполнения"}), 400
        
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        password_hash = generate_password_hash(password)
        cursor.execute("INSERT INTO users (username, password_hash, coins) VALUES (?, ?, 2450)", (username, password_hash))
        user_id = cursor.lastrowid
        
        checkpoints = [
            ('first_trip', 'available', '0/1'),
            ('100km_trip', 'claimed', '100/100')
        ]
        for cid, status, prog in checkpoints:
            cursor.execute("INSERT INTO user_checkpoints (user_id, checkpoint_id, status, progress) VALUES (?, ?, ?, ?)", (user_id, cid, status, prog))
            
        conn.commit()
        return jsonify({"success": True})
    except sqlite3.IntegrityError:
        return jsonify({"success": False, "error": "Данное имя пользователя уже зарегистрировано"}), 400
    except Exception as e:
        return jsonify({"success": False, "error": f"Ошибка базы данных: {str(e)}"}), 500
    finally:
        conn.close()

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    
    if not username or not password:
        return jsonify({"success": False, "error": "Заполните все поля формы"}), 400
        
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    user = cursor.execute("SELECT id, password_hash FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()
    
    if user and check_password_hash(user[1], password):
        session['user_id'] = user[0]
        return jsonify({"success": True})
        
    return jsonify({"success": False, "error": "Неверное имя пользователя или пароль"}), 401

@app.route('/api/auth/logout', methods=['POST', 'GET'])
def logout():
    session.pop('user_id', None)
    return jsonify({"success": True})

@app.route('/api/get_profile', methods=['GET'])
def get_profile():
    if 'user_id' not in session:
        return jsonify({"success": False, "error": "Доступ запрещен. Необходима авторизация"}), 401
        
    user_id = session['user_id']
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    user = cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if not user:
        conn.close()
        return jsonify({"success": False, "error": "Пользователь не найден"}), 404
        
    checkpoints_rows = cursor.execute("SELECT * FROM user_checkpoints WHERE user_id = ?", (user_id,)).fetchall()
    checkpoints = {row['checkpoint_id']: {'status': row['status'], 'progress': row['progress']} for row in checkpoints_rows}
    
    inventory_rows = cursor.execute("SELECT * FROM user_inventory WHERE user_id = ?", (user_id,)).fetchall()
    inventory = [row['item_id'] for row in inventory_rows]
    
    routes_rows = cursor.execute("SELECT * FROM user_routes WHERE user_id = ? ORDER BY created_at DESC", (user_id,)).fetchall()
    
    routes = []
    total_km = 0
    for r in routes_rows:
        total_km += r['distance']
        routes.append({
            "start": r['start_point'], 
            "end": r['end_point'], 
            "days": r['days'], 
            "distance": r['distance'], 
            "date": r['created_at']
        })
        
    conn.close()
    return jsonify({
        "success": True, 
        "username": user['username'], 
        "coins": user['coins'], 
        "avatar": user['avatar_url'],
        "checkpoints": checkpoints, 
        "inventory": inventory, 
        "routes": routes, 
        "total_km": total_km, 
        "total_routes": len(routes)
    })

@app.route('/api/update_profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return jsonify({"success": False, "error": "Необходима авторизация"}), 401
        
    user_id = session['user_id']
    data = request.json or {}
    username = data.get('username', '').strip()
    
    if not username:
        return jsonify({"success": False, "error": "Имя пользователя не может быть пустым"}), 400
        
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE users SET username = ? WHERE id = ?", (username, user_id))
        conn.commit()
        return jsonify({"success": True})
    except sqlite3.IntegrityError:
        return jsonify({"success": False, "error": "Это имя пользователя уже занято"}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        conn.close()

@app.route('/api/generate_route', methods=['POST'])
def generate_route():
    if 'user_id' not in session:
        return jsonify({"success": False, "error": "Доступ запрещен. Войдите в систему"}), 401
        
    user_id = session['user_id']
    data = request.json or {}
    start_point = data.get('start_point', 'Москва').strip()
    end_point = data.get('end_point', 'Казань').strip()
    days = data.get('days', 4)

    prompt = (
        f"Роль: Логист. Маршрут {start_point} -> {end_point} на {days} дней.\n"
        "Выдай строго массив JSON объектов. Поля: day (число), city (текст), type (rosneft|sight|hotel), name (текст), description (текст).\n"
        "Никаких пояснений, только валидный JSON."
    )

    try:
        response = client.chat.completions.create(
            model="openai/gpt-oss-120b",
            messages=[{"role": "user", "content": prompt}]
        )
        raw_output = response.choices[0].message.content.strip()
        
        raw_output = re.sub(r'^```json\s*', '', raw_output, flags=re.IGNORECASE)
        raw_output = re.sub(r'^```\s*', '', raw_output)
        raw_output = re.sub(r'\s*```$', '', raw_output)
        
        raw_output = re.sub(r'\\(?!["\\/bfnrt])', r'\\\\', raw_output)
        
        route_points = json.loads(raw_output)
        
        features = []
        line_coordinates = []
        colors = {'start': '#ef4444', 'finish': '#b91c1c', 'rosneft': '#f59e0b', 'sight': '#10b981', 'hotel': '#3b82f6'}

        start_coords = get_city_coordinates(start_point, [37.6173, 55.7558])
        end_coords = get_city_coordinates(end_point, [49.1210, 55.7903])

        line_coordinates.append(start_coords)
        features.append({
            "type": "Feature", "geometry": {"type": "Point", "coordinates": start_coords},
            "properties": {
                "type": "start", 
                "day": 1, 
                "city": start_point, 
                "name": f"Старт: {start_point}", 
                "description": "Точка отправления автопутешествия. Проверка технического состояния автомобиля.", 
                "marker-color": "#ef4400"
            }
        })

        for pt in route_points:
            target_city = pt.get('city', start_point)
            base_coords = get_city_coordinates(target_city, start_coords)
            offset_coords = [base_coords[0] + random.uniform(-0.01, 0.01), base_coords[1] + random.uniform(-0.01, 0.01)]
            line_coordinates.append(offset_coords)
            
            features.append({
                "type": "Feature", "geometry": {"type": "Point", "coordinates": offset_coords},
                "properties": {
                    "type": pt.get('type', 'sight'),
                    "day": pt.get('day', 1),
                    "city": target_city,
                    "name": pt.get('name', 'Локация маршрута'),
                    "description": pt.get('description', ''),
                    "marker-color": colors.get(pt.get('type'), '#4986cc')
                }
            })

        line_coordinates.append(end_coords)
        features.append({
            "type": "Feature", "geometry": {"type": "Point", "coordinates": end_coords},
            "properties": {
                "type": "finish", 
                "day": days, 
                "city": end_point, 
                "name": f"Финиш: {end_point}", 
                "description": "Конечный пункт назначения. Маршрут успешно завершен!", 
                "marker-color": "#ef4400"
            }
        })
        features.append({
            "type": "Feature", 
            "geometry": {"type": "LineString", "coordinates": line_coordinates}, 
            "properties": {"stroke": "#4986cc", "stroke-width": 4}
        })

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        distance = int(days) * 230 + random.randint(20, 80)
        cursor.execute("INSERT INTO user_routes (user_id, start_point, end_point, days, distance) VALUES (?, ?, ?, ?, ?)",
                       (session['user_id'], start_point, end_point, days, distance))
        
        cursor.execute("UPDATE user_checkpoints SET progress = '1/1' WHERE user_id = ? AND checkpoint_id = 'first_trip'", (session['user_id'],))
        
        conn.commit()
        conn.close()

        return jsonify({"success": True, "geojson": {"type": "FeatureCollection", "features": features}})

    except Exception as e:
        print(f"DEBUG ERROR: {e}")
        return jsonify({"success": False, "error": f"Ошибка парсинга ответа ИИ: {str(e)}"}), 500

@app.route('/api/buy_item', methods=['POST'])
def buy_item():
    if 'user_id' not in session:
        return jsonify({"success": False, "error": "Доступ запрещен"}), 401
        
    user_id = session['user_id']
    data = request.json or {}
    item_id = data.get('item_id')
    item_name = data.get('item_name')
    price = int(data.get('price', 0))
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    user = cursor.execute("SELECT coins FROM users WHERE id = ?", (user_id,)).fetchone()
    if not user or user[0] < price:
        conn.close()
        return jsonify({"success": False, "error": "Недостаточно коинов на балансе"}), 400
        
    cursor.execute("UPDATE users SET coins = ? WHERE id = ?", (user[0] - price, user_id))
    cursor.execute("INSERT INTO user_inventory (user_id, item_id, item_name) VALUES (?, ?, ?)", (user_id, item_id, item_name))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route('/api/claim_checkpoint', methods=['POST'])
def claim_checkpoint():
    if 'user_id' not in session:
        return jsonify({"success": False, "error": "Доступ запрещен"}), 401
        
    user_id = session['user_id']
    data = request.json or {}
    checkpoint_id = data.get('checkpoint_id')
    reward = int(data.get('reward', 0))
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    user = cursor.execute("SELECT coins FROM users WHERE id = ?", (user_id,)).fetchone()
    cursor.execute("UPDATE users SET coins = ? WHERE id = ?", (user[0] + reward, user_id))
    cursor.execute("UPDATE user_checkpoints SET status = 'claimed' WHERE user_id = ? AND checkpoint_id = ?", (user_id, checkpoint_id))
    conn.commit()
    conn.close()
    return jsonify({"success": True})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8362)
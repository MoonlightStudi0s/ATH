var mapInstance = null;
var geojsonLayer = null;
var cachedProfileData = null;
var currentShopFilter = 'all';
var authMode = 'login'; // 'login' или 'register'

var shopItems = [
    { id: 'termocup', name: 'Термокружка', price: 3500, img: 'static/images/kruzhka.png' },
    { id: 'airfresher1', name: 'Освежитель для машины', price: 1400, img: 'static/images/osvezhitel1.jpg' },
    { id: 'airfresher2', name: 'Освежитель для машины', price: 1400, img: 'static/images/osvezhitel2.jpg' }
];

document.addEventListener('DOMContentLoaded', function() {
    console.log('Приложение загружено');
    checkAuthStatus();
    
    // Навигация
    var navItems = document.querySelectorAll('.nav-item[data-tab]');
    for (var i = 0; i < navItems.length; i++) {
        navItems[i].addEventListener('click', function() {
            var tab = this.getAttribute('data-tab');
            switchTab(tab);
        });
    }
    
    // Модальное окно
    var modal = document.getElementById('edit-modal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeEditModal();
            }
        });
    }
    
    // По умолчанию режим входа
    switchAuthMode('login');
});

function initMap() {
    if (mapInstance) return;
    if (typeof L === 'undefined') {
        console.error('Leaflet не загружен');
        return;
    }
    mapInstance = L.map('map').setView([55.7558, 37.6173], 6);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(mapInstance);
    setTimeout(function() {
        if (mapInstance) mapInstance.invalidateSize();
    }, 300);
}

function checkAuthStatus() {
    fetch('/api/get_profile')
        .then(function(response) { return response.json(); })
        .then(function(res) {
            console.log('Статус авторизации:', res);
            if (res.success) {
                document.getElementById('auth-screen').classList.add('hidden');
                document.getElementById('app-screen').classList.remove('hidden');
                initMap();
                updateProfileUI(res);
                updateHeroStats(res);
            } else {
                document.getElementById('auth-screen').classList.remove('hidden');
                document.getElementById('app-screen').classList.add('hidden');
            }
        })
        .catch(function(e) {
            console.error('Ошибка:', e);
            document.getElementById('auth-screen').classList.remove('hidden');
            document.getElementById('app-screen').classList.add('hidden');
        });
}

function switchAuthMode(mode) {
    authMode = mode;
    var title = document.getElementById('auth-title');
    var subtitle = document.getElementById('auth-subtitle');
    var btn = document.getElementById('auth-btn');
    var errorDiv = document.getElementById('auth-error');
    
    errorDiv.classList.add('hidden');
    
    // Обновляем табы
    document.getElementById('login-tab').classList.remove('active');
    document.getElementById('register-tab').classList.remove('active');
    
    if (mode === 'register') {
        document.getElementById('register-tab').classList.add('active');
        title.textContent = 'Регистрация';
        subtitle.textContent = 'Создайте аккаунт для доступа к системе';
        btn.textContent = 'Зарегистрироваться';
    } else {
        document.getElementById('login-tab').classList.add('active');
        title.textContent = 'Вход в систему';
        subtitle.textContent = 'Управляйте своими маршрутами эффективно';
        btn.textContent = 'Войти';
    }
}

function handleAuth(event) {
    event.preventDefault();
    console.log('Авторизация, режим:', authMode);
    
    var username = document.getElementById('auth-username').value.trim();
    var password = document.getElementById('auth-password').value.trim();
    var errorDiv = document.getElementById('auth-error');
    
    errorDiv.classList.add('hidden');
    
    if (!username || !password) {
        errorDiv.textContent = 'Заполните все поля';
        errorDiv.classList.remove('hidden');
        return;
    }
    
    var endpoint = authMode === 'register' ? '/api/auth/register' : '/api/auth/login';
    
    fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username, password: password })
    })
    .then(function(response) { return response.json(); })
    .then(function(res) {
        console.log('Ответ:', res);
        if (res.success) {
            if (authMode === 'register') {
                alert('Регистрация успешно завершена! Теперь войдите в систему.');
                switchAuthMode('login');
                document.getElementById('auth-password').value = '';
            } else {
                checkAuthStatus();
            }
        } else {
            errorDiv.textContent = res.error || 'Ошибка авторизации';
            errorDiv.classList.remove('hidden');
        }
    })
    .catch(function(e) {
        console.error('Ошибка:', e);
        errorDiv.textContent = 'Ошибка соединения с сервером';
        errorDiv.classList.remove('hidden');
    });
}

function handleLogout() {
    fetch('/api/auth/logout', { method: 'POST' })
        .then(function(response) { return response.json(); })
        .then(function(res) {
            if (res.success) {
                location.reload();
            }
        })
        .catch(function(e) {
            alert('Не удалось выйти из системы');
        });
}

function switchTab(tabId) {
    var navItems = document.querySelectorAll('.nav-item');
    for (var i = 0; i < navItems.length; i++) {
        navItems[i].classList.remove('active');
    }
    
    var sections = document.querySelectorAll('.tab-section');
    for (var j = 0; j < sections.length; j++) {
        sections[j].classList.remove('active');
    }
    
    var btn = document.querySelector('[data-tab="' + tabId + '"]');
    if (btn) btn.classList.add('active');
    
    var section = document.getElementById('tab-' + tabId);
    if (section) section.classList.add('active');
    
    var titles = {
        'main': 'Главная',
        'routes': 'Маршруты',
        'shop': 'Магазин',
        'checkpoints': 'Достижения',
        'profile': 'Профиль'
    };
    document.getElementById('page-title').textContent = titles[tabId] || tabId;
    
    if (tabId === 'routes') {
        setTimeout(function() {
            if (mapInstance) mapInstance.invalidateSize();
        }, 150);
    }
}

function updateHeroStats(res) {
    document.getElementById('hero-total-routes').textContent = res.total_routes || 0;
    document.getElementById('hero-total-km').textContent = res.total_km || 0;
    document.getElementById('hero-coins').textContent = res.coins || 0;
}

function updateProfileUI(res) {
    cachedProfileData = res;
    document.getElementById('global-coins-display').textContent = res.coins || 0;
    document.getElementById('stat-coins').textContent = res.coins || 0;
    document.getElementById('stat-routes').textContent = res.total_routes || 0;
    document.getElementById('stat-km').textContent = res.total_km || 0;
    document.getElementById('profile-username').textContent = res.username || 'Пользователь';
    
    var firstChar = res.username ? res.username.charAt(0).toUpperCase() : 'U';
    document.getElementById('profile-avatar-char').textContent = firstChar;
    
    renderShopUI();
    renderCheckpoints(res);
    renderHistory(res);
    updateHeroStats(res);
}

function renderCheckpoints(res) {
    var cpBox = document.getElementById('checkpoints-container');
    cpBox.innerHTML = '';
    
    var checkpointData = {
        'first_trip': { title: 'Первый маршрут', desc: 'Сгенерируйте первый маршрут с помощью ИИ', reward: 100 },
        '100km_trip': { title: '100 км', desc: 'Преодолейте 100 километров', reward: 150 }
    };
    
    for (var cid in checkpointData) {
        var meta = checkpointData[cid];
        var state = res.checkpoints[cid] || { status: 'available', progress: '0/1' };
        var parts = state.progress.split('/');
        var finished = parts[0] === parts[1];
        var claimed = state.status === 'claimed';
        var progress = parseInt(parts[0]) || 0;
        var total = parseInt(parts[1]) || 1;
        
        var btnClass = claimed ? 'btn-secondary' : 'btn-primary';
        var btnText = claimed ? 'Получено ✓' : 'Получить';
        var isDisabled = claimed || !finished ? 'disabled' : '';
        
        cpBox.innerHTML += 
            '<div class="check-card">' +
                '<div class="check-info">' +
                    '<h4>' + meta.title + '</h4>' +
                    '<p>' + meta.desc + '</p>' +
                '</div>' +
                '<div style="display:flex;align-items:center;gap:16px;">' +
                    '<span class="check-progress">' + progress + '/' + total + '</span>' +
                    '<button class="btn ' + btnClass + '" ' + isDisabled + ' onclick="claimCheckpoint(\'' + cid + '\', ' + meta.reward + ')">' + btnText + '</button>' +
                '</div>' +
            '</div>';
    }
}

function renderHistory(res) {
    var histBox = document.getElementById('routes-history-list');
    histBox.innerHTML = '';
    
    if (res.routes.length === 0) {
        histBox.innerHTML = '<div class="empty-history">Вы пока не сгенерировали ни одного маршрута</div>';
    } else {
        for (var i = 0; i < res.routes.length; i++) {
            var r = res.routes[i];
            histBox.innerHTML += 
                '<div class="history-item">' +
                    '<span class="route-name">' + r.start + ' → ' + r.end + '</span>' +
                    '<span class="route-meta">' + r.days + ' дн. • ' + r.distance + ' км</span>' +
                '</div>';
        }
    }
}

function filterShop(type) {
    currentShopFilter = type;
    var filters = document.querySelectorAll('.filter-btn');
    for (var i = 0; i < filters.length; i++) {
        filters[i].classList.remove('active');
    }
    if (type === 'all') {
        if (filters[0]) filters[0].classList.add('active');
    } else {
        if (filters[1]) filters[1].classList.add('active');
    }
    renderShopUI();
}

function renderShopUI() {
    if (!cachedProfileData) return;
    var shopBox = document.getElementById('shop-products-container');
    shopBox.innerHTML = '';
    
    for (var i = 0; i < shopItems.length; i++) {
        var item = shopItems[i];
        var bought = cachedProfileData.inventory.indexOf(item.id) !== -1;
        if (currentShopFilter === 'bought' && !bought) continue;
        
        var imgSource = item.img || 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 150 150"%3E%3Crect width="150" height="150" fill="%23f3f4f6"/%3E%3Ctext x="75" y="75" text-anchor="middle" dy=".3em" fill="%239ca3af" font-family="Inter" font-size="14"%3E' + encodeURIComponent(item.name) + '%3C/text%3E%3C/svg%3E';
        
        var btnClass = bought ? 'btn-secondary' : 'btn-primary';
        var btnText = bought ? 'Куплено ✓' : 'Купить';
        var isDisabled = bought || cachedProfileData.coins < item.price ? 'disabled' : '';
        
        shopBox.innerHTML += 
            '<div class="product-card">' +
                '<div class="product-image">' +
                    '<img src="' + imgSource + '" alt="' + item.name + '">' +
                '</div>' +
                '<h4>' + item.name + '</h4>' +
                '<div class="product-price">' + item.price + ' ◆</div>' +
                '<button class="btn ' + btnClass + ' btn-block" ' + isDisabled + ' onclick="buyItem(\'' + item.id + '\', \'' + item.name + '\', ' + item.price + ')">' + btnText + '</button>' +
            '</div>';
    }
}

function generateRoute(e) {
    e.preventDefault();
    var btn = document.getElementById('submit-btn');
    btn.textContent = 'Построение...';
    btn.disabled = true;

    var startPoint = document.getElementById('start_point').value.trim();
    var endPoint = document.getElementById('end_point').value.trim();
    var days = parseInt(document.getElementById('days').value);

    fetch('/api/generate_route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            start_point: startPoint,
            end_point: endPoint,
            days: days
        })
    })
    .then(function(response) { return response.json(); })
    .then(function(res) {
        if (res.success) {
            if (geojsonLayer && mapInstance) mapInstance.removeLayer(geojsonLayer);
            
            geojsonLayer = L.geoJSON(res.geojson, {
                pointToLayer: function(f, l) {
                    return L.circleMarker(l, { 
                        radius: 8, 
                        fillColor: f.properties['marker-color'] || '#4f46e5', 
                        color: '#ffffff', 
                        weight: 2,
                        fillOpacity: 1 
                    });
                },
                onEachFeature: function(f, layer) {
                    if (f.properties) {
                        var typeLabels = {
                            'start': '🚀 Старт',
                            'finish': '🏁 Финиш',
                            'rosneft': '⛽ АЗС',
                            'sight': '🏛️ Достопримечательность',
                            'hotel': '🏨 Отель'
                        };
                        var label = typeLabels[f.properties.type] || f.properties.type;
                        layer.bindPopup(
                            '<b>' + f.properties.name + '</b><br>' +
                            '<span style="font-size:12px;color:#6b7280;">' + label + '</span><br>' +
                            '<span style="font-size:13px;">' + (f.properties.description || '') + '</span>'
                        );
                    }
                },
                style: function(f) {
                    if (f.geometry.type === 'LineString') {
                        return { 
                            color: '#4f46e5', 
                            weight: 4,
                            opacity: 0.8
                        };
                    }
                    return {};
                }
            }).addTo(mapInstance);
            
            mapInstance.fitBounds(geojsonLayer.getBounds());

            var tbody = document.getElementById('route-table-body');
            tbody.innerHTML = '';
            
            var typeLabels = {
                'start': 'Старт',
                'finish': 'Финиш',
                'rosneft': 'АЗС',
                'sight': 'Достоприм.',
                'hotel': 'Отель'
            };
            
            var features = res.geojson.features;
            for (var i = 0; i < features.length; i++) {
                var f = features[i];
                if (f.geometry.type === 'Point') {
                    var dNum = f.properties.day || '—';
                    var locationCity = f.properties.city || 'В пути';
                    var type = f.properties.type || 'sight';
                    tbody.innerHTML += 
                        '<tr>' +
                            '<td><strong>' + dNum + '</strong></td>' +
                            '<td>' + locationCity + '</td>' +
                            '<td><span class="badge type-' + type + '">' + (typeLabels[type] || type) + '</span></td>' +
                            '<td>' + f.properties.name + '</td>' +
                            '<td>' + (f.properties.description || '') + '</td>' +
                        '</tr>';
                }
            }
            document.getElementById('route-table-box').style.display = 'block';
            checkAuthStatus();
        } else {
            alert(res.error || 'Ошибка построения маршрута');
        }
    })
    .catch(function(err) {
        alert('Критическая ошибка бэкенда');
        console.error(err);
    })
    .finally(function() {
        btn.textContent = 'Построить маршрут';
        btn.disabled = false;
    });
}

function buyItem(id, name, price) {
    fetch('/api/buy_item', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item_id: id, item_name: name, price: price })
    })
    .then(function(response) { return response.json(); })
    .then(function(res) {
        if (res.success) {
            checkAuthStatus();
        } else {
            alert(res.error || 'Ошибка покупки');
        }
    })
    .catch(function(e) {
        alert('Ошибка соединения с сервером');
    });
}

function claimCheckpoint(id, reward) {
    fetch('/api/claim_checkpoint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ checkpoint_id: id, reward: reward })
    })
    .then(function(response) { return response.json(); })
    .then(function(res) {
        if (res.success) {
            checkAuthStatus();
        } else {
            alert(res.error || 'Ошибка получения награды');
        }
    })
    .catch(function(e) {
        alert('Ошибка соединения с сервером');
    });
}

function openEditModal() {
    document.getElementById('edit-username-input').value = cachedProfileData ? cachedProfileData.username : '';
    document.getElementById('edit-modal').classList.add('active');
}

function closeEditModal() {
    document.getElementById('edit-modal').classList.remove('active');
}

function saveProfile() {
    var newName = document.getElementById('edit-username-input').value.trim();
    if (!newName) {
        alert('Имя пользователя не может быть пустым');
        return;
    }
    
    fetch('/api/update_profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: newName })
    })
    .then(function(response) { return response.json(); })
    .then(function(res) {
        if (res.success) {
            closeEditModal();
            checkAuthStatus();
        } else {
            alert(res.error || 'Ошибка обновления профиля');
        }
    })
    .catch(function(e) {
        alert('Ошибка соединения с сервером');
    });
}